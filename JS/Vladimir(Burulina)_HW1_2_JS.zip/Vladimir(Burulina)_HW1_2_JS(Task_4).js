// 4***:
// Преобразовать задание 3* таким образом, чтобы возраст вводится используя функцию prompt в привязанной верстке
let age_1;
const age_2 = 18;
const age_3 = 60;

function passTwo (age_1) {
    if (age_1 && !isNaN (age_1)) {      
        if (age_1 < age_2) {
            alert ("You don't have access cause your age is " + age_1 + " It's less then ")
        } else if (age_1 >= age_2 && age_1 < age_3) {
            alert ("Welcome!")
        } else if (age_1 > age_3) {
            alert ("Keep calm and look Culture channel")
        } else alert ("Technical work");
    } else alert ("Error - unexpected symbol!!!");
}
passTwo (prompt ('Enter your number'));